# Write a funcion to return the sum of all numbers in a list.
# sample List : (8, 2, 3, 0, 7)
# Expected Output : 20

def sum(num):
	t = 0
	for x in num:
		t += x
	return t
print(sum((8, 2, 3, 0, 7)))


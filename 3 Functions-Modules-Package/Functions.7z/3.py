# Write a function to calculate and return the factorial of a number (a non-negative 3 integer)

def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

n=int(input("Input a number : "))
print(factorial(n))
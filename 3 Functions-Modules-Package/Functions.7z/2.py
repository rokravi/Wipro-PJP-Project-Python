# Write a function to return the reverse of a string. 
# sample string : “l234abcd” 
# Expectd Output : “dcba432l”

def reverse(s):
    str = ""
    for i in s:
        str = i + str
    return str
    
print(reverse('l234abcd'))

# Write a function that accepts a string and prints the number of upper case letters and lower case letters in it

def up_low(s):      
    u = sum(1 for i in s if i.isupper())
    l = sum(1 for i in s if i.islower())
    print("No. of Upper case characters :",u)
    print("No. of Lower case characters :",l)

up_low("Ravi Singh")

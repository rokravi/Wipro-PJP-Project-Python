n=input("enter the string: ")
l=n.split('-')
l.sort()
print('-'.join(l))
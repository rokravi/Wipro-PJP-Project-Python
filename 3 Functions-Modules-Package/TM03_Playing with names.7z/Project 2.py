import function

def main():
    str = input("enter a String ")
    function.ispalindrome(str)
    function.count_the_vowels(str)
    function.frequency_of_letters(str)

if __name__ == "__main__":
    main()
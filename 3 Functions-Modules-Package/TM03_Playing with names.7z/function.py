def ispalindrome(name):
    if name == name[::-1]:
        print('yes it is palindrome')
    else:
        print('Not it is not a palindrome')

def count_the_vowels(name):
    c=0
    for i in name:
        if(i=='a' or i=='e' or i=='i' or i=='o' or i=='u' or i=='A' or i=='E' or i=='I' or i=='O' or i=='U'):
                c=c+1
    print("No. of vowels:",c)

def frequency_of_letters(name):  
    print("Frequency of letters: ",end='')
    dict_counter = {}
    for char in name:  
        if not dict_counter or char not in dict_counter.keys(): 
            dict_counter.update({char: 1}) 
        elif char in dict_counter.keys():
            dict_counter[char] += 1
    for key, val in dict_counter.items():
        print(key,end='-')
        print(val,end=', ')
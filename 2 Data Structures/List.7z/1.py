# write a program to create of list of 5 integrs and display the list items. Access the individual elements through index.
li = [2,5,7,8,9]
print(li)

print(li[0])
print(li[1])
print(li[2])
print(li[3])
print(li[4])
# Write a program to reverse the order of the items in the list.
li = [2,5,7,8,9]
print(li)
print(li[::-1])
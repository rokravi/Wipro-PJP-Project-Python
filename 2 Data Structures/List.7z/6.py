# Write a program to insert a new item before the second element in an existing list.
li1 = [2,5,7,8,9]

li1.insert(1,3)
print(li1)

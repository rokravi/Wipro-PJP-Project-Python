# Write a program to append a new item at the end of list.
li = [2,5,7,8,9]
print(li)
li.append(10)
print(li)
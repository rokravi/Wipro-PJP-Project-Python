# Write a program to print the number of occurance of a specified element in list.
li = [2,5,7,8,9,5,5,4,2]
print(li.count(5))
print(li.count(2))

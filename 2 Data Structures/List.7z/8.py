# Write a program to remove the first oocurance of a specified element from a list.
li = [2,5,7,8,5,9]
li.remove(5)
print(li)



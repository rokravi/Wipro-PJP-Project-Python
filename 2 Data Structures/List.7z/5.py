# Write a program to append the items of list1 to list2 in the front
li1 = [2,5,7,8,9]
li2 = [8,10,14,7,3]

li2[:0] = li1
print(li2)


# Write a program to remove the item from a specified index in a list.
li = [2,5,7,8,9]

del li[2]
print(li)

people = {'Ravi':'watches Anime','Jeff': 'Is afraid of Dogs','David':'Plays the piano','Jason':'Can fly an aeroplane','Jil':'loves street food'}
for x,y in people.items():
    print(f'{x} : {y}')
people['Jil']='does bike stunt'
print(people)
people['Amit'] = 'does digital Marketing'
print(people)
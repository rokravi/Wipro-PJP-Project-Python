# write a program to remove a given item from a set.
s = {1, 5, 7, 9, 3}
print(s.remove(7))
print(s)

# write a program to create an intersection of set.
r = {1, 5, 2, 9, 8}
s = {2, 4, 6, 8, 10}
print(r.intersection(s))



# Write a program to find the maximum and minimum value in a set.
r = {1, 5, 2, 9, 8}
print(max(r))
print(min(r))
string =input("Enter String ")
print(string.count('Alex'))
# Write a Python program to sum all the items in a dictionary, considering the values of int type.
my_dict = {'A':10,'B':-5,'C':20}
print(sum(my_dict.values()))


# write a program to add a key and value to a dictonary.
# Sample Dictonary {0:10,1:20}
# Expected Result {0:10,1:20:2:30}
x = {0:10,1:20}
x.update({2:30})
print(x)
# Write a Python program to iterate over dictionaries using for loops and print the keys alone, value alone and both keys and values.

d = {'Red': 1, 'Green': 2, 'Blue': 3} 
for color, value in d.items():
    print(color)
for color, value in d.items():
    print(value)
for color, value in d.items():
    print(color, 'to ', d[color])

# Write a program that will check whether a given String is Palindrome or not.
str = 'Ravi'
if str == str[::-1]:
    print('Palindrome')
else:
    print('Not a palindrome')


# Write a program to count the number of upper and lower case letters in a String.
s = "Ravi Singh"
l,u = 0,0
for i in s:
	if (i>='a'and i<='z'):
		l=l+1				
	if (i>='A'and i<='Z'):
		u=u+1

print('Lower case: ',l)
print('Upper case: ',u)

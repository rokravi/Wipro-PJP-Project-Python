# write a program to accept two numbers as command line arguments and display their sum
import sys
x=int(sys.argv[1])
y=int(sys.argv[2])
sum=x+y
print("Sum is :",sum)
#  write a program to accept a welcome message as command line arguments and display the file name along with the welcome message.

import sys
print(sys.argv[0],sys.argv[1])
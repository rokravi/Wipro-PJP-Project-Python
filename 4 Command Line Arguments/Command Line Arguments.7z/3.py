# write a program to accept 10 number through command line arguments and calculate the sum of prime_sum number among them.

import sys

nums = sys.argv

def prime_sum(nums):
    total = 0
    count = 1
    for i in range(1, len(nums)):
        if int(nums[i]) > 1:
            for j in range(2, int(nums[i])):
                if (int(nums[i]) % j) == 0:
                    break
            else:
                total += int(nums[i])
        elif int(nums[i]) == 1:
            total += int(nums[i])
        else:
            pass
        count += 1
    print("\nTotal : {}".format(total))

prime_sum(nums)

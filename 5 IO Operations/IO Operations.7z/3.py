# Write a program to accept input from user and append it to a txt file.

n = input("enter text ")
fname = open("sample.txt" , "a")
fname.write("\n")
fname.write(n)
fname.close()
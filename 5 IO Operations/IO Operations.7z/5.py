# Write a program to find the longest word from the txt file contents, assuming that the file will have only one longest word in it.

def longest_words(filename):
    with open(filename, 'r') as infile:
        words = infile.read().split()
    max_len = len(max(words, key=len))
    return [word for word in words if len(word) == max_len]
 
print(longest_words('sample.txt'))
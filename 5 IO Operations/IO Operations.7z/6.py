# Write a program to count the frequency of a user entered word in a txt file.
from collections import Counter

def word_count(fname):
    with open(fname) as f:
            return Counter(f.read().split())

print("Number of words :",word_count("sample.txt"))
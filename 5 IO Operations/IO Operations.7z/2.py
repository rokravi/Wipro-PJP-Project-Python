# Write a program to read first n lines from a txt file. Get n as user input.

file = open("sample.txt")
n = int(input("enter no. of lines. "))
for i in range(n):
    line = file.readline()
    print(line)
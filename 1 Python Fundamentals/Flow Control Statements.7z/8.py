# Write a program to print the sum of all the digits of a given number.
# Example:I/P:1234
# O/P:10
num = int(input("Enter a Number: "))
sum = 0
while (num != 0):    
    sum = sum + (num % 10)
    num = num//10
print(sum)

# Write a program to print prime numbers between 10 and 99.
for x in range(10,100):
    count = 0
    for y in range(2,x//2+1):
        if(x % y == 0):
            count = count + 1
            break

    if (count == 0 and x != 1):
        print(x)

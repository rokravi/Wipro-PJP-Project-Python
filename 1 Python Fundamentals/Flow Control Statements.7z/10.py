# Write a program to find if the number is palindrome or not
# Example:1I/P:110011
# O/P: 110011 is a palindrome.
# Example:2I/P:1234
# O/P: 1234 is not a palindrome.

n = int(input("Enter a no. "))
temp = n
rev = 0
while(n > 0):
    a = n % 10
    rev = rev * 10 + a
    n = n // 10 
if(temp==rev):
    print(temp, 'is Palindrome ')
else:
    print(temp, 'is not Palindrome ')
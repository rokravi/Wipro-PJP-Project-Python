# Given two non-negative values, print true if they have the same last digit, such as with 27 and 57.
def lastDigit(x, y):
   if x%10 == y%10:
       return True
   else:
       return False
print(lastDigit(7, 17))
print(lastDigit(6, 17))
print(lastDigit(3, 113))
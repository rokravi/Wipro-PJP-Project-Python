# Write a program to check given no is odd or even
a = int(input('Enter any Number '))
if(a%2==0):
    print('Even')
else:
    print('Odd')
# Write a program to print even numbers between 23 and 57. Each number should be printed in a separate row.
for x in range(23,58):
    if (x%2==0):
        print(x)
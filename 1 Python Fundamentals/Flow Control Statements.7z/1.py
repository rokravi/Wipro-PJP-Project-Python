# write a program to check given no is positive, negative or zero
a = int(input('Enter any Number '))
if(a>0):
    print('Positive')
elif(a<0):
    print('Negative')
else:
    print('Zero')

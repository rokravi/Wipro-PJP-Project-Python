# Write a program to print numbers from 1 to 10 in a single row with one tab space.
for x in range(1,11):
    print(x,end='   ')

a = int(input('how far you want to travel in miles: '))
if(a<=3):
    print('I suggest Bicycle to your destination.')
elif(a>3 and a<300):
    print('I suggest Motor-Cycle to your destination')
else:
    print('I suggest Super-Car to your destination')
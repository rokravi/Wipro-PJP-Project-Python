a=0.51
print('How much does it cost to operate one server per day.? ')
print(f'It will cost ${a*24} per day ')
print('How much does it cost to operate one server per week.? ')
print(f'It will cost ${a*24*7} per week')
print('How much does it cost to operate one server per month.? ')
print(f'It will cost ${a*24*30} per month')
print('How many days can I operate one server with $918.? ')
print(f'{918/a} days')

# Declare a list with 10 integers and ask the user to enter an index. Check whether the number in that index is positive or negative number. If any invalid index is entered, handle the exception and print an error message.

li = [-1,2,3,-4,5,-6,7,-8,9,-10]
i = int(input("enter index no. "))
try:
    if li[i] > 0:
        print ("Positive")
    else:
        print ("Negative")
except:
    print ("Index out of range")

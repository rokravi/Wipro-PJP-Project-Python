# Write a program to accept the file name to be opened from the user, if file exist print the contents of the file in title case or else handle the exception and print an error message.

try:
    f = open("sample.txt","r")
    for line in f:
        print(line)
except FileNotFoundError:
    print("file not found")
# Write a program to accept two number from the user and perform divisor. If any exception occurs, print error message or else print the result.

try:  
    a = int(input("Enter a: "))    
    b = int(input("Enter b: "))    
    c = a/b
    print(c)
except:  
    print("Can't divide with zero")
# Write a program to accept a number from the user and wheaher its a prime or not. if the user enters anything other than number, handle the exception and print the message.

try:
    num = int(input("ener a no. "))
    if num > 1:
        for i in range(2, int(num/2)+1):
            if (num % i) == 0:
                print("Not a prime number")
                break
        else:
            print("Prime number")
    
    else:
        print("Not a prime number")
except Exception:
    print("Enter value is not a Integer Type")